package com.project.buyeritemservice.service;

import com.project.buyeritemservice.pojo.BillPojo;

public interface BillService {
	BillPojo saveBill(BillPojo billPojo);

}
